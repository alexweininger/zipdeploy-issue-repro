import React from 'react';

function App() {
  const value = 'World';
  return <div>Hello {value}</div>;
}

export default App;
